
package login2;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

public class ToDoTest {
    
    public ToDoTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

 
    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        ToDo.main(args);
        fail("The test case is a prototype.");
    }
    
    // Test for Task Description length
    @Test
    public void testTaskDescriptionLength() {
        String shortDescription = "Create Login to authenticate users";
        String longDescription = "This is a task description with more than 50 characters which should fail.";
        
        assertTrue("Task successfully captured", shortDescription.length() <= 50);
        assertFalse("Please enter a task description of less than 50 characters", longDescription.length() <= 50);
    }

    // Test for TaskID format
    @Test
    public void testTaskIDFormat() {
        String taskId1 = "AD:1:BYN"; 
        String taskId2 = "CR:0:IKE"; 

        assertTrue(taskId1.matches("^[A-Z]{2}:[0-9]+:[A-Z]{3}$"));
        assertTrue(taskId2.matches("^[A-Z]{2}:[0-9]+:[A-Z]{3}$"));
    }

    // Test for Total Hours Accumulation
    @Test
    public void testTotalHoursAccumulation() {
        int[] durations1 = {8, 10}; 
        int totalHours1 = 0;
        for (int duration : durations1) {
            totalHours1 += duration;
        }
        assertEquals(18, totalHours1);

        int[] durations2 = {10, 12, 55, 11, 1}; 
        int totalHours2 = 0;
        for (int duration : durations2) {
            totalHours2 += duration;
        }
        assertEquals(89, totalHours2);
    }
}

