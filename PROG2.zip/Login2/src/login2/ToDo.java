package login2;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

class ToDo {

    JFrame frame = new JFrame("To-Do List");
    DefaultListModel<String> listModel = new DefaultListModel<>();
    JList<String> list = new JList<>(listModel);

    JTextField taskNameField = new JTextField(20);
    JTextField taskDescriptionField = new JTextField(20);
    JTextField developerDetailsField = new JTextField(20);
    JTextField taskDurationField = new JTextField(20);
    String[] statusOptions = {"To Do", "Done", "Doing"};
    JComboBox<String> taskStatusComboBox = new JComboBox<>(statusOptions); //The combobox for Task Status
    
    JLabel totalHoursLabel = new JLabel("Total Hours: 0");
    double totalHours = 0;
    
    JButton addTaskButton = new JButton("Add Task");

    static int taskCounter = 0;  // Implemented a Static variable to keep track of task numbers

    public ToDo() {

        JPanel inputPanel = new JPanel(new GridLayout(8, 2));
        
        inputPanel.add(new JLabel("Task Status:"));
        inputPanel.add(taskStatusComboBox);
        
        inputPanel.add(new JLabel("Developer Details:"));
        inputPanel.add(developerDetailsField);       
        
        inputPanel.add(new JLabel("Task Number:"));
        JLabel taskNumberLabel = new JLabel();  // This label displays task number
        inputPanel.add(taskNumberLabel);
        
        inputPanel.add(new JLabel("Task Name:"));
        inputPanel.add(taskNameField);
        
        inputPanel.add(new JLabel("Task Description:"));
        inputPanel.add(taskDescriptionField);
    
        inputPanel.add(new JLabel("Task ID:"));
        JLabel taskIDLabel = new JLabel();  // This label displays the task ID
        inputPanel.add(taskIDLabel);
        
        inputPanel.add(new JLabel("Task Duration(Hours):"));
        inputPanel.add(taskDurationField);
        

        addTaskButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String taskName = taskNameField.getText();
                String taskDescription = taskDescriptionField.getText();
                String developerDetails = developerDetailsField.getText();
                String taskDurationText = taskDurationField.getText();
                String taskStatus = (String) taskStatusComboBox.getSelectedItem();

                if (!taskName.isEmpty() && !taskDescription.isEmpty() && 
                    !developerDetails.isEmpty() && !taskDurationText.isEmpty() && 
                    taskStatus != null && developerDetails.length() >= 3 && taskName.length() >= 2) {

                    if (taskDescription.length() > 50) {
                        JOptionPane.showMessageDialog(frame, "Please enter a task description of less than 50 characters", "Description Too Long", JOptionPane.WARNING_MESSAGE);
                        return;
                    }

                    try {
                        double taskDuration = Double.parseDouble(taskDurationText);
                        totalHours += taskDuration;
                        totalHoursLabel.setText("Total Hours: " + totalHours);

                        String taskNumber = String.valueOf(taskCounter);
                        String taskID = (taskName.substring(0, 2) + ":" + taskNumber + ":" + developerDetails.substring(developerDetails.length() - 3)).toUpperCase();
                        String taskDetails = String.format("Status: %s, Developer: %s, Number: %s, Name: %s, Description: %s, ID: %s, Duration: %.2f hours", 
                        taskStatus, developerDetails, taskNumber, taskName, taskDescription, taskID, taskDuration);
                        listModel.addElement(taskDetails);
                        
                        // Increment the task counter
                        taskCounter++; 

                        taskNameField.setText("");
                        taskDescriptionField.setText("");
                        developerDetailsField.setText("");
                        taskDurationField.setText("");
                        taskStatusComboBox.setSelectedIndex(0);
                        
                        // This updates the task number and task ID labels
                        taskNumberLabel.setText(taskNumber);
                        taskIDLabel.setText(taskID);

                        JOptionPane.showMessageDialog(frame, "Task successfully captured", "Success", JOptionPane.INFORMATION_MESSAGE);

                    } catch (NumberFormatException ex) {
                        JOptionPane.showMessageDialog(frame, "Please enter a valid number for Task Duration E.g. 12, 15, 2.", "Invalid Input", JOptionPane.WARNING_MESSAGE);
                    }
                } else {
                    JOptionPane.showMessageDialog(frame, "Please fill in all fields correctly.", "Incomplete Data", JOptionPane.WARNING_MESSAGE);
                }
            }
        });

        inputPanel.add(new JLabel(""));
        inputPanel.add(addTaskButton);

        frame.add(inputPanel, BorderLayout.NORTH);
        frame.add(new JScrollPane(list), BorderLayout.CENTER);
        frame.add(totalHoursLabel, BorderLayout.SOUTH);

        frame.setSize(400, 400);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setVisible(true);
    }

    public static void main(String[] args) {
        new ToDo();
    }
}




