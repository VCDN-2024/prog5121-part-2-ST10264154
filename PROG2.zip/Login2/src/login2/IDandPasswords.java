package login2;
import java.util.HashMap;

public class IDandPasswords {
       
        HashMap<String, String> logininfo = new HashMap<String, String>();

IDandPasswords(){
    
        logininfo.put("Admin", "Admin123");
        logininfo.put("User", "User123");
    }
  
   
    protected HashMap getLoginInfo(){
        return logininfo;
    }
}

