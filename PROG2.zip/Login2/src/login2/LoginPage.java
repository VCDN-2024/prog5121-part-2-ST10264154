
package login2;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class LoginPage implements ActionListener {

    JFrame frame = new JFrame();
    JButton loginB = new JButton("Login");
    JButton loginS = new JButton("Sign up");
    JTextField userIDField = new JTextField();
    JPasswordField userPasswordField = new JPasswordField();
    JLabel userIDLabel = new JLabel("Username: ");
    JLabel userPasswordLabel = new JLabel("Password: ");
    JLabel messageLabel = new JLabel();

    HashMap<String, String> logindata = new HashMap<String, String>();
    private HashMap logininfo;

    LoginPage(HashMap<String, String> loginInformation) {
        logindata = loginInformation;

        userIDLabel.setBounds(50, 100, 75, 25);
        userPasswordLabel.setBounds(50, 150, 75, 25);

        userIDField.setBounds(125, 100, 200, 25);
        userPasswordField.setBounds(125, 150, 200, 25);

        loginB.setBounds(125, 200, 100, 25);
        loginB.setFocusable(false);
        loginB.addActionListener(this);
       loginB.setBackground(new Color(203, 195, 227));
        
        loginS.setBounds(225,200,100,25);
        loginS.setFocusable(false);
        loginS.addActionListener(this);
        loginS.setBackground(Color.PINK);

        messageLabel.setBounds(40, 250, 300, 35);
        messageLabel.setFont(new Font(null,Font.ITALIC,12));

        frame.add(userIDLabel);
        frame.add(userPasswordLabel);
        frame.add(userIDField);
        frame.add(userPasswordField);
        frame.add(loginB);
        frame.add(loginS);
        frame.add(messageLabel);

        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(420, 420);
        frame.setLayout(null);
        frame.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String userID = userIDField.getText();
        String password = String.valueOf(userPasswordField.getPassword());

        if (logindata.containsKey(userID)) {
            if (logindata.get(userID).equals(password)) {
                messageLabel.setText("Login successful!");
                frame.dispose();
                UserWelcome welcomePage = new UserWelcome(userID);
                
                NewWelcome easyKanban = new NewWelcome();
            } else {
    JOptionPane.showMessageDialog(null, "Password is not correctly formatted, please ensure that the password contains at least 8 characters, a capital letter, a number, and a special character.", "Message", JOptionPane.ERROR_MESSAGE);
}
        } else {
    JOptionPane.showMessageDialog(null, "Username is not correctly formatted, please ensure that your username contains an underscore and is no more than 5 characters in length", "Message", JOptionPane.ERROR_MESSAGE);
}  
        
       // else  {
 //   JOptionPane.showMessageDialog(null, "Username or password incorrect, please try again", "Message", JOptionPane.ERROR_MESSAGE);}
    }

}