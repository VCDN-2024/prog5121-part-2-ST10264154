
package login2;


import javax.swing.JOptionPane;


public class UserWelcome {
    

    
    UserWelcome(String userID){

 JOptionPane.showMessageDialog(null, "Welcome " + userID + ". It is great to see you again.");
        
        
        
    }
    
}
