
package login2;

public class Task {
    private String taskName;
    private String taskDescription;
    private String developerDetails;
    private double taskDuration;
    private String taskStatus;
    private static int taskCounter = 0;
    private int taskNumber;

  
    public Task(String taskName, String taskDescription, String developerDetails, double taskDuration, String taskStatus) {
        this.taskName = taskName;
        this.taskDescription = taskDescription;
        this.developerDetails = developerDetails;
        this.taskDuration = taskDuration;
        this.taskStatus = taskStatus;
        this.taskNumber = ++taskCounter;
    }

    // This is the method that is used to check if task description is not more than 50 characters
    public boolean checkTaskDescription() {
    return taskDescription.length() <= 50;
    }

    //This is the method that is used to create and return the task ID
    public String createTaskID() {
    String taskID = (taskName.substring(0, 2) + ":" + taskNumber + ":" + developerDetails.substring(developerDetails.length() - 3)).toUpperCase();
    return taskID;
    }

    //This is the method that is used to print the full task details
    public String printTaskDetails() {
    String taskID = createTaskID();
    return String.format("Status: %s, Developer: %s, Number: %d, Name: %s, Description: %s, ID: %s, Duration: %.2f hours", 
                                taskStatus, developerDetails, taskNumber, taskName, taskDescription, taskID, taskDuration);
    }


    public double getTaskDuration() {
    return taskDuration;
    }

    // Static method returns the hours entered
    public static double returnTotalHours(Task[] tasks) {
    double totalHours = 0;
    for (Task task : tasks) {
    totalHours += task.getTaskDuration();
        }
    return totalHours;
    }
}