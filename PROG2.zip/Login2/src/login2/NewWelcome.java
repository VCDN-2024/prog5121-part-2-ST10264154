package login2;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.Color;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

public class NewWelcome {

    JFrame frame = new JFrame();
    JLabel newWelcomeLabel = new JLabel("Welcome");
    JButton addButton = new JButton("Add Tasks");
    JButton reportButton = new JButton("Show Report");
    JButton quitButton = new JButton("Quit");

    public NewWelcome() {

        newWelcomeLabel.setBounds(50, 50, 300, 70);
        newWelcomeLabel.setFont(new Font(null, Font.PLAIN, 20));
        newWelcomeLabel.setText("Welcome to EasyKanban");

        addButton.setBounds(125, 150, 150, 25);
        addButton.setFocusable(false);
        addButton.setBackground(new Color(119,221,119));
         addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // This opens the Add Tasks frame, showing the To-Do list
                new ToDo();
            }
        });

        reportButton.setBounds(125, 200, 150, 25);
        reportButton.setFocusable(false);
        reportButton.setBackground(new Color(253,253,150));
        reportButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // When Show Report is pressed, "Coming soon" will be displayed
                JOptionPane.showMessageDialog(frame, "Coming soon");
            }
        });

        quitButton.setBounds(125, 250, 150, 25);
        quitButton.setFocusable(false);
        quitButton.setBackground(new Color(255 ,127 ,127));
        quitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // This is for the quit button
                System.exit(0);
            }
        });

        frame.add(newWelcomeLabel);
        frame.add(addButton);
        frame.add(reportButton);
        frame.add(quitButton);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(420, 420);
        frame.setLayout(null);
        frame.setVisible(true);
    }

    public static void main(String[] args) {
        new NewWelcome();
    }
}

    
    

